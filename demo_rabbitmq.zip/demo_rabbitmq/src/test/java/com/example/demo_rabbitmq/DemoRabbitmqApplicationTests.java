package com.example.demo_rabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRabbitmqApplicationTests {

	@Test
	void contextLoads() {
	}

}
